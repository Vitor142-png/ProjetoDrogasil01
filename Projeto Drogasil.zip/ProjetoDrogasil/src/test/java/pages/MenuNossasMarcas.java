package pages;

import elementos.Elementos;

public class MenuNossasMarcas {
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	public void NossasMarcas() throws Exception {
		metodos.clicar(elemento.getClicarMenu());
		metodos.clicar(elemento.getMenuNossasMarcas());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_NossasMarcas");

	}

}
