package pages;

import elementos.Elementos;

public class MenuPromocoesDoMes {
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	public void PromocoesDoMes() throws Exception {
		metodos.clicar(elemento.getClicarMenu());
		metodos.clicar(elemento.getMenuPromocoesMes());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_PromocoesDoMes");

	}

}
