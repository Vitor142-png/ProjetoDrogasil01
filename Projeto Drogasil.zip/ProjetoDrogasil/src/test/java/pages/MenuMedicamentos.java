package pages;

import java.io.IOException;

import elementos.Elementos;



public class MenuMedicamentos {
	
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();
	
	
	public void Medicamentos () throws Exception {
		metodos.clicar(elemento.getMenuMedicamentos());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_Medicamenos");
		
	}
	
	

}
