package pages;

import elementos.Elementos;

public class MenuCompreCategoria {
	
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();
	
	public void CompreCategoria () throws Exception {
		
		metodos.esperar(8000);
		metodos.clicar(elemento.getClicarMenu());
		metodos.screenshot("CT01_Clicar_Menu_Compre_Categoria");
				
		
	}

}
