package pages;

import elementos.Elementos;

public class MenuSaude {
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	public void Saude() throws Exception {
		metodos.clicar(elemento.getClicarMenu());
		metodos.clicar(elemento.getMenuSaude());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_Sa�de");
		
		
	}

}
