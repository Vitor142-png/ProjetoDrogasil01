package pages;

import elementos.Elementos;

public class MenuCuidadosDiarios {
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	public void CuidadosDiarios() throws Exception {
		metodos.clicar(elemento.getClicarMenu());
		metodos.clicar(elemento.getMenuCuidadosDiarios());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_CuidadosDiarios");

	}

}
