package pages;

import elementos.Elementos;

public class MenuVitaminasSuplementos {
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	public void VitaminasSuplementos() throws Exception {
		metodos.clicar(elemento.getClicarMenu());
		metodos.clicar(elemento.getMenuVitaminasSuplementos());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_Vitaminas Suplementos");

	}

}
