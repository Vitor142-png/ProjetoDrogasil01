package pages;

import elementos.Elementos;

public class MenuCosmeticos {
	
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	public void Cosmeticos() throws Exception {
		metodos.clicar(elemento.getClicarMenu());
		metodos.clicar(elemento.getMenuCosmeticos());
		metodos.esperar(3000);
		metodos.screenshot("CT02_Menu_Cosmeticos");
		
	}

}
