package steps;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementos.Elementos;
import pages.MenuBeleza;
import pages.MenuCompreCategoria;
import pages.MenuCosmeticos;
import pages.MenuCuidadosDiarios;
import pages.MenuMamaeBebe;
import pages.MenuMedicamentos;
import pages.MenuNossasMarcas;
import pages.MenuOrtopediaAcessorios;
import pages.MenuPromocoesDoMes;
import pages.MenuSaude;
import pages.MenuVitaminasSuplementos;
import pages.Metodos;

public class Steps {
	WebDriver driver;
	Metodos metodos = new Metodos();
	Elementos elementos = new Elementos();
	MenuCompreCategoria menuCat = new MenuCompreCategoria();
	MenuMedicamentos menuMed = new MenuMedicamentos();
	MenuSaude menuSad = new MenuSaude();
	MenuVitaminasSuplementos menuViSu = new MenuVitaminasSuplementos();
	MenuBeleza menuBel = new MenuBeleza();
	MenuCosmeticos menuCos = new MenuCosmeticos();
	MenuMamaeBebe menuMaBe = new MenuMamaeBebe();
	MenuCuidadosDiarios menuCuiD = new MenuCuidadosDiarios();
	MenuOrtopediaAcessorios menuOrto = new MenuOrtopediaAcessorios();
	MenuNossasMarcas menuMarc = new MenuNossasMarcas();
	MenuPromocoesDoMes menuProm = new MenuPromocoesDoMes();

	@Given("^que eu esteja no \"([^\"]*)\"$")
	public void que_eu_esteja_no(String url) throws Throwable {

		metodos.abrirNavegador(url);
		metodos.esperar(3000);
		metodos.clicar(elementos.getFecharCokies());

	}

	@When("^acesso o menu compre por categorias$")
	public void acesso_o_menu_compre_por_categorias() throws Throwable {
		menuCat.CompreCategoria();
		menuMed.Medicamentos();
		//menuSad.Saude();
		//menuViSu.VitaminasSuplementos();
		//menuBel.Beleza();
		//menuCos.Cosmeticos();
		//menuMaBe.MamaeBebe();
		//menuCuiD.CuidadosDiarios();
		//menuOrto.OrtopediaAcessorios();
		//menuMarc.NossasMarcas();
		//menuProm.PromocoesDoMes();
		//metodos.fecharNavegador();

	}

	@Then("^valido os topicos$")
	public void valido_os_topicos() throws Throwable {
		WebElement paginaAtual = driver.findElement(elementos.getValidarMedicamentos());
		String mensagem = paginaAtual.getText();
		assertEquals(mensagem, "Medicamentos");

	}

}