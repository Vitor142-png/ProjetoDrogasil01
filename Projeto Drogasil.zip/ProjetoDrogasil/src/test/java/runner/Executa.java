package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import pages.Browser;

//utilizei o runwith para executar as ospc�es do cucumber
@RunWith(Cucumber.class)

//aqui est�o os caminhos onde ser�o executados o runner
@CucumberOptions (
		
		//caminho da feature
		features = "src/test/resources/Features",
		
		//indica��o onde ser�o implementados os gurkins
		glue = "steps",
		
		//indica��o do que deve ser executado
		tags = "@Executa",
		
		//verifica se est� faltando implementar algum codigo 
		dryRun = false,
		
		//formata exibi��o dos caracteres especiais 
		monochrome = true,
		
		//plugim para gerar um report em html e json
		plugin = {"pretty", "html:target/report.html", "json:target/report.json"}
		
		)


public class Executa extends Browser {

	//metodo para fechar o browser
	@AfterClass
	public static void fecharPagina () {
		adriver().quit();
	}

	

	

}
