package elementos;

import org.openqa.selenium.By;

public class Elementos {
	private By clicarMenu = By.xpath("/html/body/div[4]/div[6]/div/button");
	private By menuMedicamentos = By.xpath("/html/body/div[4]/div[6]/div/ul/li[1]/a");
	private By menuSaude = By.xpath("/html/body/div[4]/div[6]/div/ul/li[2]/a");
	private By menuVitaminasSuplementos = By.xpath("/html/body/div[4]/div[6]/div/ul/li[3]/a");
	private By menuBeleza = By.xpath("/html/body/div[4]/div[6]/div/ul/li[4]/a");
	private By menuCosmeticos = By.xpath("/html/body/div[4]/div[6]/div/ul/li[5]/a");
	private By menuMaeBebe = By.xpath("/html/body/div[4]/div[6]/div/ul/li[6]/a");
	private By menuCuidadosDiarios = By.xpath("/html/body/div[4]/div[6]/div/ul/li[7]/a");
	private By menuOrtopediaAcessorios = By.xpath("/html/body/div[4]/div[6]/div/ul/li[8]/a");
	private By menuNossasMarcas = By.xpath("/html/body/div[4]/div[6]/div/ul/li[9]/a");
	private By menuPromocoesMes = By.xpath("/html/body/div[4]/div[6]/div/ul/li[10]/a");
	private By validarMedicamentos = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarSaude = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarVitaminasSuplementos = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarBeleza = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarCosmeticos = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarMaeBebe = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarCuidadosDiarios = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarOrtopediaAcessorios = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarNossasMarcas = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By validarPromocoesMes = By.xpath("/html/body/div[4]/main/div[3]/div/div/h1");
	private By FecharCokies = By.xpath("/html/body/div[8]/div[2]/div[2]/button");
    
	
	private By menuCat = By.id("697");

	public By getValidarMedicamentos() {
		return validarMedicamentos;
	}

	public By getValidarSaude() {
		return validarSaude;
	}

	public By getValidarVitaminasSuplementos() {
		return validarVitaminasSuplementos;
	}

	public By getValidarBeleza() {
		return validarBeleza;
	}

	public By getValidarCosmeticos() {
		return validarCosmeticos;
	}

	public By getValidarMaeBebe() {
		return validarMaeBebe;
	}

	public By getValidarCuidadosDiarios() {
		return validarCuidadosDiarios;
	}

	public By getValidarOrtopediaAcessorios() {
		return validarOrtopediaAcessorios;
	}

	public By getValidarNossasMarcas() {
		return validarNossasMarcas;
	}

	public By getValidarPromocoesMes() {
		return validarPromocoesMes;
	}

	public By getMenuMedicamentos() {
		return menuMedicamentos;
	}

	public By getMenuSaude() {
		return menuSaude;
	}

	public By getMenuVitaminasSuplementos() {
		return menuVitaminasSuplementos;
	}

	public By getMenuBeleza() {
		return menuBeleza;
	}

	public By getMenuCosmeticos() {
		return menuCosmeticos;
	}

	public By getMenuMaeBebe() {
		return menuMaeBebe;
	}

	public By getMenuCuidadosDiarios() {
		return menuCuidadosDiarios;
	}

	public By getMenuOrtopediaAcessorios() {
		return menuOrtopediaAcessorios;
	}

	public By getMenuNossasMarcas() {
		return menuNossasMarcas;
	}

	public By getMenuPromocoesMes() {
		return menuPromocoesMes;
	}

	public By getClicarMenu() {
		return clicarMenu;
	}

	public By getMenuCat() {
		return menuCat;
	}

	public By getFecharCokies() {
		return FecharCokies;
	}

}
